module.exports = {
    database: 'shop',
    username: 'root',
    password:'whz123456#',
    host:'localhost'
 };